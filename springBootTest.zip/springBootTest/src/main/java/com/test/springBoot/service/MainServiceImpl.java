package com.test.springBoot.service;

import com.test.springBoot.vo.TestVO;

public class MainServiceImpl {
	
	public TestVO index(TestVO vo) {
		return vo;
		
	}
}
