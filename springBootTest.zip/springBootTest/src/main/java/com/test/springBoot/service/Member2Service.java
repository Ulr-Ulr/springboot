package com.test.springBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.springBoot.dao.Member2DAO;
import com.test.springBoot.vo.Member2VO;

@Service
public class Member2Service {

	@Autowired
	Member2DAO member2Dao;
	
	public List<Member2VO> selectAllMembers(){
		return member2Dao.selectAllMembers();
	}
}
