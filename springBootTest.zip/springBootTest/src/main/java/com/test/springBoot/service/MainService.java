package com.test.springBoot.service;

import com.test.springBoot.vo.TestVO;

public class MainService {
	
	//index
	TestVO index(TestVO vo) throws Exception {
		return vo;
	}
}
